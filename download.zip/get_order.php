<?php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

include "db.php";


$role =
$_GET['role'] ?? '';

$user_id =
intval($_GET['user_id'] ?? 0);


if(!$role || !$user_id){

    echo json_encode([

        "status" => "error",

        "message" => "Missing parameters"

    ]);

    exit();
}



/* =========================================================
   OWNER ORDERS
========================================================= */

if($role == "owner"){

    $sql = "

    SELECT

        orders.*,

        owners.shop_name,

        customers.full_name AS customer_name,
        customers.email AS customer_email,
        customers.phone AS customer_phone

    FROM orders

    LEFT JOIN owners
    ON orders.owner_id = owners.id

    LEFT JOIN customers
    ON orders.customer_id = customers.id

    WHERE orders.owner_id = '$user_id'

    ORDER BY orders.id DESC

    ";

}

/* =========================================================
   CUSTOMER ORDERS
========================================================= */

else{

    $sql = "

    SELECT

        orders.*,

        owners.shop_name,
        owners.owner_name,
        owners.phone AS owner_phone,
        owners.city,
        owners.address,
        owners.description,
        owners.working_hours,
        owners.working_days

    FROM orders

    LEFT JOIN owners
    ON orders.owner_id = owners.id

    WHERE orders.customer_id = '$user_id'

    ORDER BY orders.id DESC

    ";

}
/* =========================================================
   QUERY
========================================================= */

$result = mysqli_query($conn, $sql);


if(!$result){

    echo json_encode([

        "status" => "error",

        "message" => mysqli_error($conn)

    ]);

    exit();
}


$data = [];

while($row = mysqli_fetch_assoc($result)){

    $data[] = $row;
}


echo json_encode([

    "status" => "success",

    "data" => $data

]);


mysqli_close($conn);

?>