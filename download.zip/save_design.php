<?php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

include "db.php";


// ─────────────────────────────────────────────
// GET FORM DATA
// ─────────────────────────────────────────────

$id =
intval($_POST['id'] ?? 0);

$owner_id =
intval($_POST['owner_id'] ?? 0);

$title =
trim($_POST['title'] ?? '');

$category =
trim($_POST['category'] ?? '');

$price =
trim($_POST['price'] ?? '');

$delivery_days =
trim($_POST['delivery_days'] ?? '');

$description =
trim($_POST['description'] ?? '');


// ─────────────────────────────────────────────
// VALIDATION
// ─────────────────────────────────────────────

if(
    !$owner_id ||
    !$title ||
    !$category ||
    !$price ||
    !$delivery_days
){

    echo json_encode([

        "status" => "error",

        "message" => "Missing required fields"

    ]);

    exit();
}



// ─────────────────────────────────────────────
// IMAGE UPLOAD
// ─────────────────────────────────────────────

$image_url = "";


// NEW IMAGE UPLOADED

if(
    isset($_FILES['image']) &&
    $_FILES['image']['name']
){

    $folder = "uploads/";


    if(
        !file_exists($folder)
    ){

        mkdir($folder, 0777, true);
    }


    $fileName =

    time() . "_" .

    basename(
        $_FILES['image']['name']
    );


    $target =
    $folder . $fileName;


    if(

        move_uploaded_file(

            $_FILES['image']['tmp_name'],

            $target
        )

    ){

        $image_url =

        "https://tailorfinder.infinityfree.me/" .

        $target;
    }
}



// ─────────────────────────────────────────────
// UPDATE DESIGN
// ─────────────────────────────────────────────

if($id > 0){

    // KEEP OLD IMAGE IF NEW NOT UPLOADED

    if(!$image_url){

        $old =
        mysqli_query(

            $conn,

            "SELECT image_url
             FROM designs
             WHERE id='$id'
             LIMIT 1"
        );


        if(mysqli_num_rows($old)){

            $oldData =
            mysqli_fetch_assoc($old);

            $image_url =
            $oldData['image_url'];
        }
    }


    $sql = "

    UPDATE designs

    SET

        title='$title',
        category='$category',
        price='$price',
        delivery_days='$delivery_days',
        image_url='$image_url',
        description='$description'

    WHERE id='$id'

    ";

}else{


// ─────────────────────────────────────────────
// INSERT NEW DESIGN
// ─────────────────────────────────────────────

    $sql = "

    INSERT INTO designs
    (
        owner_id,
        title,
        category,
        price,
        delivery_days,
        image_url,
        description
    )

    VALUES
    (
        '$owner_id',
        '$title',
        '$category',
        '$price',
        '$delivery_days',
        '$image_url',
        '$description'
    )

    ";
}



// ─────────────────────────────────────────────
// EXECUTE QUERY
// ─────────────────────────────────────────────

if(
    mysqli_query($conn, $sql)
){

    echo json_encode([

        "status" => "success"

    ]);

}else{

    echo json_encode([

        "status" => "error",

        "message" => mysqli_error($conn)

    ]);
}


mysqli_close($conn);

?>