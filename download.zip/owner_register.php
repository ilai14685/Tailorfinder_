<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
include "db.php";

$shop_name   = trim(mysqli_real_escape_string($conn, $_POST['shop_name']       ?? ''));
$owner_name  = trim(mysqli_real_escape_string($conn, $_POST['owner_name']      ?? ''));
$email       = trim(mysqli_real_escape_string($conn, $_POST['email']           ?? ''));
$password    = $_POST['password'] ?? '';
$phone       = trim(mysqli_real_escape_string($conn, $_POST['phone']           ?? ''));
$address     = trim(mysqli_real_escape_string($conn, $_POST['address']         ?? ''));
$city        = trim(mysqli_real_escape_string($conn, $_POST['city']            ?? ''));
$price_range = trim(mysqli_real_escape_string($conn, $_POST['price_range']     ?? ''));
$specs       = trim(mysqli_real_escape_string($conn, $_POST['specializations'] ?? ''));
$exp         = intval($_POST['experience_years'] ?? 0);
$w_hours     = trim(mysqli_real_escape_string($conn, $_POST['working_hours']   ?? ''));
$w_days      = trim(mysqli_real_escape_string($conn, $_POST['working_days']    ?? ''));
$description = trim(mysqli_real_escape_string($conn, $_POST['description']     ?? ''));

if (!$shop_name || !$owner_name || !$email || !$password || !$phone || !$address || !$city) {
    echo json_encode(["status" => "error", "message" => "Please fill all required fields"]);
    exit();
}
if (strlen($password) < 6) {
    echo json_encode(["status" => "error", "message" => "Password must be at least 6 characters"]);
    exit();
}

$check = mysqli_query($conn, "SELECT id FROM owners WHERE email='$email'");
if (mysqli_num_rows($check) > 0) {
    echo json_encode(["status" => "error", "message" => "Email already registered"]);
    exit();
}

$hashed = password_hash($password, PASSWORD_DEFAULT);
$sql = "INSERT INTO owners
        (shop_name, owner_name, email, password, phone, address, city,
         price_range, specializations, experience_years, working_hours, working_days, description)
        VALUES
        ('$shop_name','$owner_name','$email','$hashed','$phone','$address','$city',
         '$price_range','$specs',$exp,'$w_hours','$w_days','$description')";

$result = mysqli_query($conn, $sql);

if ($result) {
    echo json_encode([
        "status"  => "success",
        "message" => "Shop registered successfully",
        "user"    => [
            "id"         => mysqli_insert_id($conn),
            "shop_name"  => $shop_name,
            "owner_name" => $owner_name,
            "email"      => $email,
            "city"        => $city,
            "role"        => "owner"
        ]
    ]);
} else {
    echo json_encode(["status" => "error", "message" => "Registration failed: " . mysqli_error($conn)]);
}
mysqli_close($conn);
?>