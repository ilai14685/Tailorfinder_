<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
include "db.php";

$order_id = intval($_POST['order_id'] ?? 0);
$owner_id = intval($_POST['owner_id'] ?? 0);
$status   = trim(mysqli_real_escape_string($conn, $_POST['status'] ?? ''));

$allowed = ['pending','confirmed','in_progress','ready','delivered','cancelled'];
if (!in_array($status, $allowed)) {
    echo json_encode(["status" => "error", "message" => "Invalid status"]);
    exit();
}

$sql    = "UPDATE orders SET status='$status' WHERE id=$order_id AND owner_id=$owner_id";
$result = mysqli_query($conn, $sql);

echo $result
    ? json_encode(["status" => "success", "message" => "Status updated"])
    : json_encode(["status" => "error",   "message" => mysqli_error($conn)]);

mysqli_close($conn);
?>