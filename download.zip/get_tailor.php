<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
include "db.php";

$search = trim(mysqli_real_escape_string($conn, $_GET['search'] ?? ''));
$city   = trim(mysqli_real_escape_string($conn, $_GET['city']   ?? ''));
$cat    = trim(mysqli_real_escape_string($conn, $_GET['cat']    ?? ''));

$sql = "SELECT id, shop_name, owner_name, city, address, phone,
               description, specializations, experience_years,
               price_range, rating, total_reviews, is_verified,
               is_open, working_hours, working_days
        FROM owners WHERE 1=1";

if ($search) $sql .= " AND (shop_name LIKE '%$search%' OR owner_name LIKE '%$search%')";
if ($city)   $sql .= " AND city LIKE '%$city%'";
if ($cat)    $sql .= " AND specializations LIKE '%$cat%'";
$sql .= " ORDER BY rating DESC, total_reviews DESC";

$result  = mysqli_query($conn, $sql);
$tailors = [];
while ($row = mysqli_fetch_assoc($result)) {
    $tailors[] = $row;
}

echo json_encode(["status" => "success", "data" => $tailors]);
mysqli_close($conn);
?>