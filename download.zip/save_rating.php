<?php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

include "db.php";


$customer_id = $_POST['customer_id'] ?? '';
$owner_id    = $_POST['owner_id'] ?? '';
$rating      = $_POST['rating'] ?? '';
$review      = $_POST['review'] ?? '';



if(
    !$customer_id ||
    !$owner_id ||
    !$rating
){

    echo json_encode([
        "status" => "error",
        "message" => "Missing fields"
    ]);

    exit();
}



/* INSERT REVIEW */

$sql = "

INSERT INTO reviews
(
    customer_id,
    owner_id,
    rating,
    comment
)

VALUES
(
    '$customer_id',
    '$owner_id',
    '$rating',
    '$review'
)

";


$result = mysqli_query($conn, $sql);



if($result){

    echo json_encode([
        "status" => "success"
    ]);

}else{

    echo json_encode([
        "status" => "error",
        "message" => mysqli_error($conn)
    ]);

}


mysqli_close($conn);

?>