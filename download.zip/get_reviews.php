<?php

header('Content-Type: application/json');

include "db.php";


// ─────────────────────────────────────────────
// GET PARAMETERS
// ─────────────────────────────────────────────

$owner_id =
intval($_GET['owner_id'] ?? 0);


$customer_id =
intval($_GET['customer_id'] ?? 0);


// ─────────────────────────────────────────────
// WHERE CONDITION
// ─────────────────────────────────────────────

$where = "";


if($owner_id){

    $where =
    "WHERE r.owner_id = $owner_id";

}
else if($customer_id){

    $where =
    "WHERE r.customer_id = $customer_id";
}
else{

    echo json_encode([
        "status" => "error",
        "message" => "Missing ID"
    ]);

    exit();
}


// ─────────────────────────────────────────────
// SQL QUERY
// ─────────────────────────────────────────────

$sql = "

SELECT

    r.id,
    r.rating,
    r.comment,
    r.created_at,

    c.full_name AS customer_name,

    o.shop_name

FROM reviews r

JOIN customers c
ON r.customer_id = c.id

JOIN owners o
ON r.owner_id = o.id

$where

ORDER BY r.created_at DESC

";


// ─────────────────────────────────────────────
// EXECUTE QUERY
// ─────────────────────────────────────────────

$result =
mysqli_query($conn, $sql);


// ─────────────────────────────────────────────
// CHECK QUERY
// ─────────────────────────────────────────────

if(!$result){

    echo json_encode([
        "status" => "error",
        "message" => mysqli_error($conn)
    ]);

    exit();
}


// ─────────────────────────────────────────────
// FETCH DATA
// ─────────────────────────────────────────────

$reviews = [];


while($row = mysqli_fetch_assoc($result)){

    $reviews[] = $row;
}


// ─────────────────────────────────────────────
// RESPONSE
// ─────────────────────────────────────────────

echo json_encode([
    "status" => "success",
    "data" => $reviews
]);


// ─────────────────────────────────────────────
// CLOSE CONNECTION
// ─────────────────────────────────────────────

mysqli_close($conn);

?>