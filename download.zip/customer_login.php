<?php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

include "db.php";


// ─────────────────────────────────────────────
// GET FORM DATA
// ─────────────────────────────────────────────

$email =
trim(
    mysqli_real_escape_string(
        $conn,
        $_POST['email'] ?? ''
    )
);


$password =
$_POST['password'] ?? '';


// ─────────────────────────────────────────────
// VALIDATION
// ─────────────────────────────────────────────

if(!$email || !$password){

    echo json_encode([

        "status"  => "error",

        "message" =>
        "Please fill all fields"

    ]);

    exit();
}


// ─────────────────────────────────────────────
// CHECK CUSTOMER EXISTS
// ─────────────────────────────────────────────

$sql = "

SELECT *

FROM customers

WHERE email = '$email'

LIMIT 1

";


$result =
mysqli_query($conn, $sql);


if(mysqli_num_rows($result) === 0){

    echo json_encode([

        "status"  => "error",

        "message" =>
        "No account found with this email"

    ]);

    exit();
}


// ─────────────────────────────────────────────
// FETCH CUSTOMER
// ─────────────────────────────────────────────

$customer =
mysqli_fetch_assoc($result);


// ─────────────────────────────────────────────
// VERIFY PASSWORD
// ─────────────────────────────────────────────

if(

    !password_verify(
        $password,
        $customer['password']
    )

){

    echo json_encode([

        "status"  => "error",

        "message" =>
        "Incorrect password"

    ]);

    exit();
}


// ─────────────────────────────────────────────
// LOGIN SUCCESS
// ─────────────────────────────────────────────

echo json_encode([

    "status"  => "success",

    "message" =>
    "Login successful",

    "user" => [

        "id" =>
        $customer['id'],

        "full_name" =>
        $customer['full_name'],

        "email" =>
        $customer['email'],

        "phone" =>
        $customer['phone'],

        "city" =>
        $customer['city'],

        "role" =>
        "customer"
    ]

]);


// ─────────────────────────────────────────────
// CLOSE CONNECTION
// ─────────────────────────────────────────────

mysqli_close($conn);

?>