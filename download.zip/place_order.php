<?php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

include "db.php";


/* =========================================================
   GET VALUES
========================================================= */

$customer_id =
intval($_POST['customer_id'] ?? 0);

$owner_id =
intval($_POST['owner_id'] ?? 0);

$order_description =
trim($_POST['order_description'] ?? '');

$measurements =
trim($_POST['measurements'] ?? '');

$special_instructions =
trim($_POST['special_instructions'] ?? '');

$delivery_date =
trim($_POST['delivery_date'] ?? '');


/* =========================================================
   VALIDATION
========================================================= */

if(
    !$customer_id ||
    !$owner_id ||
    !$order_description
){

    echo json_encode([

        "status" => "error",

        "message" => "Missing required fields"

    ]);

    exit();
}



/* =========================================================
   EMPTY DATE FIX
========================================================= */

if($delivery_date == ''){

    $delivery_date = NULL;

}else{

    $delivery_date = "'$delivery_date'";
}



/* =========================================================
   INSERT ORDER
========================================================= */

$sql = "

INSERT INTO orders
(
    customer_id,
    owner_id,
    order_description,
    measurements,
    special_instructions,
    delivery_date,
    status
)

VALUES
(
    '$customer_id',
    '$owner_id',
    '$order_description',
    '$measurements',
    '$special_instructions',
    $delivery_date,
    'pending'
)

";



/* =========================================================
   EXECUTE
========================================================= */

if(mysqli_query($conn, $sql)){

    echo json_encode([

        "status" => "success",

        "message" => "Order placed successfully"

    ]);

}else{

    echo json_encode([

        "status" => "error",

        "message" => mysqli_error($conn)

    ]);
}


mysqli_close($conn);

?>