<?php

$conn = new mysqli("localhost", "root", "", "tailorfinder");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "Database Connected Successfully";

?>