<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
include "db.php";

$full_name = trim(mysqli_real_escape_string($conn, $_POST['full_name'] ?? ''));
$email     = trim(mysqli_real_escape_string($conn, $_POST['email']     ?? ''));
$password  = $_POST['password'] ?? '';
$phone     = trim(mysqli_real_escape_string($conn, $_POST['phone']     ?? ''));
$city      = trim(mysqli_real_escape_string($conn, $_POST['city']      ?? ''));

if (!$full_name || !$email || !$password || !$phone || !$city) {
    echo json_encode(["status" => "error", "message" => "Please fill all fields"]);
    exit();
}
if (strlen($password) < 6) {
    echo json_encode(["status" => "error", "message" => "Password must be at least 6 characters"]);
    exit();
}

$check = mysqli_query($conn, "SELECT id FROM customers WHERE email='$email'");
if (mysqli_num_rows($check) > 0) {
    echo json_encode(["status" => "error", "message" => "Email already registered"]);
    exit();
}

$hashed = password_hash($password, PASSWORD_DEFAULT);
$sql = "INSERT INTO customers (full_name, email, password, phone, city)
        VALUES ('$full_name','$email','$hashed','$phone','$city')";
$result = mysqli_query($conn, $sql);

if ($result) {
    echo json_encode([
        "status"  => "success",
        "message" => "Account created successfully",
        "user"    => [
            "id"        => mysqli_insert_id($conn),
            "full_name" => $full_name,
            "email"     => $email,
            "phone"     => $phone,
            "city"      => $city,
            "role"      => "customer"
        ]
    ]);
} else {
    echo json_encode(["status" => "error", "message" => "Registration failed: " . mysqli_error($conn)]);
}
mysqli_close($conn);
?>