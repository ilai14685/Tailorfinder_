<?php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

include "db.php";


// ─────────────────────────────────────────────
// GET DESIGN ID
// ─────────────────────────────────────────────

$id =
intval($_POST['id'] ?? 0);


// ─────────────────────────────────────────────
// VALIDATION
// ─────────────────────────────────────────────

if(!$id){

    echo json_encode([

        "status" => "error",

        "message" => "Missing parameters"

    ]);

    exit();
}



// ─────────────────────────────────────────────
// DELETE DESIGN
// ─────────────────────────────────────────────

$sql = "

DELETE FROM designs

WHERE id = '$id'

";


if(
    mysqli_query($conn, $sql)
){

    echo json_encode([

        "status" => "success"

    ]);

}else{

    echo json_encode([

        "status" => "error",

        "message" => mysqli_error($conn)

    ]);
}


mysqli_close($conn);

?>