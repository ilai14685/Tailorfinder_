<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
include "db.php";

$category = trim(mysqli_real_escape_string($conn, $_GET['category'] ?? ''));
$owner_id = intval($_GET['owner_id'] ?? 0);

$sql = "SELECT d.*, o.shop_name, o.city, o.is_verified
        FROM designs d JOIN owners o ON d.owner_id = o.id
        WHERE 1=1";

if ($category) $sql .= " AND d.category='$category'";
if ($owner_id) $sql .= " AND d.owner_id=$owner_id";
$sql .= " ORDER BY d.is_featured DESC, d.likes DESC, d.created_at DESC";

$result  = mysqli_query($conn, $sql);
$designs = [];
while ($row = mysqli_fetch_assoc($result)) {
    $designs[] = $row;
}

echo json_encode(["status" => "success", "data" => $designs]);
mysqli_close($conn);
?>