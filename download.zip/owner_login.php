<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
include "db.php";

$email    = trim(mysqli_real_escape_string($conn, $_POST['email']    ?? ''));
$password = $_POST['password'] ?? '';

if (!$email || !$password) {
    echo json_encode(["status" => "error", "message" => "Please fill all fields"]);
    exit();
}

$result = mysqli_query($conn, "SELECT * FROM owners WHERE email='$email' LIMIT 1");

if (mysqli_num_rows($result) === 0) {
    echo json_encode(["status" => "error", "message" => "Owner account not found"]);
    exit();
}

$owner = mysqli_fetch_assoc($result);

if (!password_verify($password, $owner['password'])) {
    echo json_encode(["status" => "error", "message" => "Incorrect password"]);
    exit();
}

echo json_encode([
    "status"  => "success",
    "message" => "Login successful",
    "user"    => [
        "id"         => $owner['id'],
        "shop_name"  => $owner['shop_name'],
        "owner_name" => $owner['owner_name'],
        "email"      => $owner['email'],
        "phone"      => $owner['phone'],
        "city"       => $owner['city'],
        "role"       => "owner"
    ]
]);
mysqli_close($conn);
?>