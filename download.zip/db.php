<?php

// DATABASE CONFIGURATION

$host =
"sql300.infinityfree.com";


$user =
"if0_41906526";


$password =
"Ilayaraja14";


$database =
"if0_41906526_tailorfinder";


// DATABASE CONNECTION

$conn = mysqli_connect(
    $host,
    $user,
    $password,
    $database
);


// CHECK CONNECTION

if(!$conn){

    die(
        json_encode([
            "status" => "error",
            "message" => mysqli_connect_error()
        ])
    );
}


// CHARACTER ENCODING

mysqli_set_charset(
    $conn,
    "utf8mb4"
);

?>