-- ============================================================
-- TAILORFINDER DATABASE STRUCTURE
-- ============================================================

-- ============================================================
-- CUSTOMERS TABLE
-- ============================================================

CREATE TABLE IF NOT EXISTS customers (

    id INT AUTO_INCREMENT PRIMARY KEY,

    full_name VARCHAR(100) NOT NULL,

    email VARCHAR(150) NOT NULL UNIQUE,

    password VARCHAR(255) NOT NULL,

    phone VARCHAR(20),

    address TEXT,

    city VARCHAR(100),

    latitude DECIMAL(10,8),

    longitude DECIMAL(11,8),

    profile_image VARCHAR(255),

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP

);



-- ============================================================
-- OWNERS TABLE
-- ============================================================

CREATE TABLE IF NOT EXISTS owners (

    id INT AUTO_INCREMENT PRIMARY KEY,

    shop_name VARCHAR(150) NOT NULL,

    owner_name VARCHAR(100) NOT NULL,

    email VARCHAR(150) NOT NULL UNIQUE,

    password VARCHAR(255) NOT NULL,

    phone VARCHAR(20) NOT NULL,

    address TEXT NOT NULL,

    city VARCHAR(100) NOT NULL,

    latitude DECIMAL(10,8),

    longitude DECIMAL(11,8),

    description TEXT,

    profile_image VARCHAR(255),

    shop_image VARCHAR(255),

    specializations VARCHAR(255),

    experience_years INT DEFAULT 0,

    price_range VARCHAR(50),

    rating DECIMAL(2,1) DEFAULT 0.0,

    total_reviews INT DEFAULT 0,

    is_verified BOOLEAN DEFAULT FALSE,

    is_open BOOLEAN DEFAULT TRUE,

    working_hours VARCHAR(100),

    working_days VARCHAR(100),

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP

);



-- ============================================================
-- DESIGNS TABLE
-- ============================================================

CREATE TABLE IF NOT EXISTS designs (

    id INT AUTO_INCREMENT PRIMARY KEY,

    owner_id INT NOT NULL,

    title VARCHAR(150) NOT NULL,

    description TEXT,

    image_url VARCHAR(255) NOT NULL,

    category VARCHAR(100),

    price DECIMAL(10,2),

    delivery_days INT,

    is_featured BOOLEAN DEFAULT FALSE,

    likes INT DEFAULT 0,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (owner_id)
    REFERENCES owners(id)
    ON DELETE CASCADE

);



-- ============================================================
-- ORDERS TABLE
-- ============================================================

CREATE TABLE IF NOT EXISTS orders (

    id INT AUTO_INCREMENT PRIMARY KEY,

    customer_id INT NOT NULL,

    owner_id INT NOT NULL,

    design_id INT,

    order_description TEXT,

    measurements TEXT,

    special_instructions TEXT,

    status ENUM(
        'pending',
        'confirmed',
        'in_progress',
        'ready',
        'delivered',
        'cancelled'
    ) DEFAULT 'pending',

    total_amount DECIMAL(10,2),

    advance_paid DECIMAL(10,2) DEFAULT 0,

    delivery_date DATE,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

    FOREIGN KEY (customer_id)
    REFERENCES customers(id)
    ON DELETE CASCADE,

    FOREIGN KEY (owner_id)
    REFERENCES owners(id)
    ON DELETE CASCADE,

    FOREIGN KEY (design_id)
    REFERENCES designs(id)
    ON DELETE SET NULL

);



-- ============================================================
-- REVIEWS TABLE
-- ============================================================

CREATE TABLE IF NOT EXISTS reviews (

    id INT AUTO_INCREMENT PRIMARY KEY,

    customer_id INT NOT NULL,

    owner_id INT NOT NULL,

    order_id INT,

    rating INT NOT NULL,

    comment TEXT,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (customer_id)
    REFERENCES customers(id)
    ON DELETE CASCADE,

    FOREIGN KEY (owner_id)
    REFERENCES owners(id)
    ON DELETE CASCADE,

    FOREIGN KEY (order_id)
    REFERENCES orders(id)
    ON DELETE SET NULL

);



-- ============================================================
-- FAVORITES TABLE
-- ============================================================

CREATE TABLE IF NOT EXISTS favorites (

    id INT AUTO_INCREMENT PRIMARY KEY,

    customer_id INT NOT NULL,

    owner_id INT,

    design_id INT,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (customer_id)
    REFERENCES customers(id)
    ON DELETE CASCADE,

    FOREIGN KEY (owner_id)
    REFERENCES owners(id)
    ON DELETE CASCADE,

    FOREIGN KEY (design_id)
    REFERENCES designs(id)
    ON DELETE CASCADE

);







-- ============================================================
-- SAMPLE DESIGNS
-- ============================================================

INSERT INTO designs (

    owner_id,
    title,
    description,
    image_url,
    category,
    price,
    delivery_days,
    is_featured

)

VALUES

(
    1,
    'Designer Bridal Lehenga',
    'Hand embroidered bridal lehenga',
    'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=400',
    'Bridal',
    12000,
    21,
    TRUE
),

(
    1,
    'Silk Saree Blouse',
    'Custom silk blouse',
    'https://images.unsplash.com/photo-1583391733956-6c78276477e2?w=400',
    'Traditional',
    2500,
    7,
    FALSE
),

(
    2,
    'Business Formal Suit',
    'Premium formal suit',
    'https://images.unsplash.com/photo-1594938298603-c8148c4b8e3d?w=400',
    'Formal',
    7500,
    14,
    TRUE
),

(
    2,
    'Casual Kurta Set',
    'Comfortable kurta',
    'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?w=400',
    'Casual',
    1500,
    5,
    FALSE
),

(
    3,
    'Classic Sherwani',
    'Royal sherwani',
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400',
    'Traditional',
    18000,
    30,
    TRUE
),

(
    3,
    'Corporate Blazer',
    'Professional blazer',
    'https://images.unsplash.com/photo-1617137968427-85924c800a22?w=400',
    'Formal',
    5000,
    10,
    FALSE
);


